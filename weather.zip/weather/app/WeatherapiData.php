<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class WeatherapiData extends Model
{
    protected $table = "weatherapidata";
    protected $guarded = ['id'];

    public $timestamps = true;    
}
