<?php

namespace App\Http\Controllers;

use App\WeatherapiData;
use GuzzleHttp\Client;
use Log;

class WeatherController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    { 
        //
    }
    /**
     * Process json
     *
     * @return converted currencies
     */
    public function fetchAPIData()
    {  
        // response as per Fixer io output
        $response = ["success"=>false];

        $apiData = $this->fetchWeatherData();
        $response['error'] = "Unable to fetch data. Please try after sometime.";
        if($apiData['status'] != 200)
        { 
             Log::error("Weather API Error".$apiData['data']);
             return $response;
        }

        WeatherapiData::create(['api_response'=>$apiData['data']]);

        $response = ["success"=>true, "message"=>"Data stored" ];
        return $response;
    }

    
    /**
     * Fetch data from Weather API
     *
     * @return data
     */
    public function fetchWeatherData()
    {
        $baseUrl = env('WEATHER_API_URL');
        return $this->fetchData($baseUrl); 
    }

    public function fetchData($url)
    {

        try { 
            $client = new \GuzzleHttp\Client(['http_errors' => false]);
            $response = $client->request('GET', $url);
            $statusCode = $response->getStatusCode();
            $body = $response->getBody()->getContents();
        }
        catch (Guzzle\Http\Exception\ClientErrorResponseException $e)
        {
            $statusCode = 400;
            $body = $e->getMessage();
        }
        return ['status'=>$statusCode, 'data'=>$body];
    }


}
