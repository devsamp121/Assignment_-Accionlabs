<?php

namespace App\Http\Controllers;
 
use App\Libraries\CurrencyMaster;
use Illuminate\Http\Request;

class ConverterTwoController extends Controller
{ 
    protected $masterData;
    /**
     * Create a new controller instance.
     *
     * @return void
     */ 
    public function __construct(CurrencyMaster $curMaster)
    { 
        $this->masterData = $curMaster;
    }

    /**
     * Process json
     *
     * @return converted currencies
     */
    public function getConversions(Request $request)
    {   
        $response = ["success"=>false, "error" => ''];
 
        $userCurrency = $request->query('currency');
        if(!$userCurrency)
        {
            $response["error"] = "Please provide a currency input.";
            return $response;
        }
        $validCurrencies = env('SUPPORTED_CURRENCY');
        $validCurrencies = explode(",", $validCurrencies);
        
        if(!in_array($userCurrency, $validCurrencies))
        {
            $response["error"] = "Invalid currency value entered.";
            return $response;
        }

        $fxData = $this->masterData->fixerDataByCurrency($userCurrency);
        $bcData = $this->masterData->fetchBlockchainData();

        if(!$fxData || !$bcData)
        {
            $response["error"] = "Unable to fetch data. Please try after sometime.";
            return $response;
        }
 
        $newRates = array_merge((array)$fxData->rates, (array)$bcData->$userCurrency );
        $fxData->rates = (object)$newRates;
        
        return (array)$fxData;
    }
}
