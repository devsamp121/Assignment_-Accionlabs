<?php

namespace App\Libraries;

use GuzzleHttp\Client;
use Log;

class CurrencyMaster
{
    public function fixerDataByCurrency($currency)
    { 
        return $this->fetchFixerData('&symbols='.$currency);
    }

    private function fetchFixerData($path)
    {
        $baseUrl   = env('FIXERIO_BASE_URL');
        $accessKey = env('FIXERIO_ACCESS_KEY');
        $symbols   = env('SUPPORTED_CURRENCY');
 
        $baseUrl = $baseUrl.'latest?access_key='.$accessKey . $path;
        
        $fixerData = $this->clientConnector($baseUrl); 
 
        if($fixerData['status'] != 200)
        {    
             Log::error("Fixer Server Error :".$fixerData['data']);
             return [];
        }
        $fixerData = $this->responseHandler($fixerData['data']);

        // return if any error from fixer io
        if($fixerData->success == false)
        { 
             Log::error("Fixer API Response Error : ".$fixerData['data']);
             return [];
        }
        return $fixerData;
    }

    public function fetchBlockchainData()
    {
        $baseUrl        = env('BLOCKCHAIN_URL');
        $blockchainData = $this->clientConnector($baseUrl); 

        if($blockchainData['status'] != 200)
        { 
             Log::error("Blockchain Error".$blockchainData['data']);
             return $response;
        }
        return $this->responseHandler($blockchainData['data']);
    }

    private function responseHandler($response)
    { 
        if ($response) {
            return json_decode($response);
        }        
        return [];
    }

    private function clientConnector($url)
    { 
        try { 
            $client = new \GuzzleHttp\Client(['http_errors' => false]);
            $response = $client->request('GET', $url);
            $statusCode = $response->getStatusCode();
            $body = $response->getBody()->getContents();
        }
        catch (Guzzle\Http\Exception\ClientErrorResponseException $e)
        {
            $statusCode = 400;
            $body = $e->getMessage();
        }
        return ['status' => $statusCode, 'data'=>$body];
    }
}
