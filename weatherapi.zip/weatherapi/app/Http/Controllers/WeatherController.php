<?php

namespace App\Http\Controllers;

use App\Models\WeatherapiData;
use GuzzleHttp\Client;
use Log;

class WeatherController extends Controller
{ 
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    { 
        //
    }
    /**
     * Process json
     *
     * @return converted currencies
     */
    public function fetchAPIData()
    {  
        // response as per Fixer io output
        $response = ["success"=>false];

        // Validate for last fetched data
        $latestRecord = WeatherapiData::latest()->first();

        if($latestRecord)
        {   
            $lastDate = date("d-m-Y h:i:s a", strtotime( $latestRecord->created_at) );
            $nextDate = date("d-m-Y h:i:s a", strtotime( "+1 hour", strtotime( $latestRecord->created_at) ) );
            if( time() < strtotime($nextDate) )
            {
                 $response['error'] = "Data already updated within last one hour. Please try after : ".$nextDate;
                return $response;
            } 
        }

        $cities = env('CITIES');
        $cities = explode(',', $cities);
        foreach( $cities as $city )
        {
            $apiData = $this->fetchWeatherData($city);
            $response['error'] = "Unable to fetch data. Please try after sometime.";
            if($apiData['status'] != 200)
            { 
                 Log::error("Weather API Error".$apiData['data']);
                 return $response;
            }
            WeatherapiData::create(['city'=>$city, 'api_response'=>$apiData['data']]);
        }
         
        $response = ["success"=>true, "message"=>"Data stored successfully." ];
        return $response;
    }

    
    /**
     * Fetch data from Weather API
     *
     * @return data
     */
    public function fetchWeatherData($city)
    {
        $baseUrl = env('WEATHER_API_URL');
        $key     = env('API_KEY');
        $url     = $baseUrl. "?appid=".$key."&q=". $city.",in";
        return $this->fetchData($url); 
    }

    public function fetchData($url)
    {

        try { 
            $client = new \GuzzleHttp\Client(['http_errors' => false]);
            $response = $client->request('GET', $url);
            $statusCode = $response->getStatusCode();
            $body = $response->getBody()->getContents();
        }
        catch (Guzzle\Http\Exception\ClientErrorResponseException $e)
        {
            $statusCode = 400;
            $body = $e->getMessage();
        }
        return ['status'=>$statusCode, 'data'=>$body];
    }


}
